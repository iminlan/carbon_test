from django.apps import AppConfig


class CatcherConfig(AppConfig):
    name = 'catcher'
